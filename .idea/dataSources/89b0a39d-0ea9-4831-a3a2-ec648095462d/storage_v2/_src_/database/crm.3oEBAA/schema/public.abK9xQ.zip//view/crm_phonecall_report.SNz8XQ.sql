create view crm_phonecall_report
            (id, opening_date, date_closed, state, user_id, team_id, partner_id, duration, company_id, priority,
             nbr_cases, create_date, delay_close, delay_open)
as
SELECT id,
       date_open                                                            AS opening_date,
       date_closed,
       state,
       user_id,
       team_id,
       partner_id,
       duration,
       company_id,
       priority,
       1                                                                    AS nbr_cases,
       create_date,
       EXTRACT(epoch FROM date_closed - create_date) / (3600 * 24)::numeric AS delay_close,
       EXTRACT(epoch FROM date_open - create_date) / (3600 * 24)::numeric   AS delay_open
FROM crm_phonecall c;

alter table crm_phonecall_report
    owner to crm;

