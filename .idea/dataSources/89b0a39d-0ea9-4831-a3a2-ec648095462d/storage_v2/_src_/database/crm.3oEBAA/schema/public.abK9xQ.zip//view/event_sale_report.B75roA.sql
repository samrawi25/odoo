create view event_sale_report
            (id, event_registration_id, company_id, event_id, event_ticket_id, event_registration_create_date,
             event_registration_name, event_registration_state, active, sale_order_id, sale_order_line_id, sale_status,
             event_type_id, event_date_begin, event_date_end, event_ticket_price, sale_order_date, invoice_partner_id,
             sale_order_partner_id, sale_order_state, sale_order_user_id, product_id, sale_price, sale_price_untaxed,
             is_published)
as
SELECT row_number() OVER (ORDER BY event_registration.id) AS id,
       event_registration.id                              AS event_registration_id,
       event_registration.company_id,
       event_registration.event_id,
       event_registration.event_ticket_id,
       event_registration.create_date                     AS event_registration_create_date,
       event_registration.name                            AS event_registration_name,
       event_registration.state                           AS event_registration_state,
       event_registration.active,
       event_registration.sale_order_id,
       event_registration.sale_order_line_id,
       event_registration.sale_status,
       event_event.event_type_id,
       event_event.date_begin                             AS event_date_begin,
       event_event.date_end                               AS event_date_end,
       event_event_ticket.price                           AS event_ticket_price,
       sale_order.date_order                              AS sale_order_date,
       sale_order.partner_invoice_id                      AS invoice_partner_id,
       sale_order.partner_id                              AS sale_order_partner_id,
       sale_order.state                                   AS sale_order_state,
       sale_order.user_id                                 AS sale_order_user_id,
       sale_order_line.product_id,
       CASE
           WHEN sale_order_line.product_uom_qty = 0::numeric THEN 0::numeric
           ELSE sale_order_line.price_total /
                CASE COALESCE(sale_order.currency_rate, 0::numeric)
                    WHEN 0 THEN 1.0
                    ELSE sale_order.currency_rate
                    END / sale_order_line.product_uom_qty
           END                                            AS sale_price,
       CASE
           WHEN sale_order_line.product_uom_qty = 0::numeric THEN 0::numeric
           ELSE sale_order_line.price_subtotal /
                CASE COALESCE(sale_order.currency_rate, 0::numeric)
                    WHEN 0 THEN 1.0
                    ELSE sale_order.currency_rate
                    END / sale_order_line.product_uom_qty
           END                                            AS sale_price_untaxed,
       event_event.is_published
FROM event_registration
         LEFT JOIN event_event ON event_event.id = event_registration.event_id
         LEFT JOIN event_event_ticket ON event_event_ticket.id = event_registration.event_ticket_id
         LEFT JOIN sale_order ON sale_order.id = event_registration.sale_order_id
         LEFT JOIN sale_order_line ON sale_order_line.id = event_registration.sale_order_line_id;

alter table event_sale_report
    owner to crm;

