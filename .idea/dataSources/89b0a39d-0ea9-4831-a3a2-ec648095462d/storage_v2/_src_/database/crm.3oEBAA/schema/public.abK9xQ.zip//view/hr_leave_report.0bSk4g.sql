create view hr_leave_report
            (id, leave_id, employee_id, name, number_of_days, leave_type, category_id, department_id, holiday_status_id,
             state, holiday_type, date_from, date_to, company_id)
as
SELECT row_number() OVER (ORDER BY employee_id) AS id,
       leave_id,
       employee_id,
       name,
       number_of_days,
       leave_type,
       category_id,
       department_id,
       holiday_status_id,
       state,
       holiday_type,
       date_from,
       date_to,
       company_id
FROM (SELECT allocation.id                  AS leave_id,
             allocation.employee_id,
             allocation.private_name        AS name,
             allocation.number_of_days,
             allocation.category_id,
             allocation.department_id,
             allocation.holiday_status_id,
             allocation.state,
             allocation.holiday_type,
             allocation.date_from,
             allocation.date_to,
             'allocation'::text             AS leave_type,
             allocation.employee_company_id AS company_id
      FROM hr_leave_allocation allocation
               JOIN hr_employee employee ON allocation.employee_id = employee.id
      WHERE employee.active IS TRUE
        AND allocation.active IS TRUE
      UNION ALL
      SELECT request.id                                               AS leave_id,
             request.employee_id,
             request.private_name                                     AS name,
             request.number_of_days * '-1'::integer::double precision AS number_of_days,
             request.category_id,
             request.department_id,
             request.holiday_status_id,
             request.state,
             request.holiday_type,
             request.date_from,
             request.date_to,
             'request'::text                                          AS leave_type,
             request.employee_company_id                              AS company_id
      FROM hr_leave request
               JOIN hr_employee employee ON request.employee_id = employee.id
      WHERE employee.active IS TRUE
        AND request.active IS TRUE) leaves;

alter table hr_leave_report
    owner to crm;

