create view im_livechat_report_operator
            (id, partner_id, livechat_channel_id, nbr_channel, channel_id, start_date, rating, duration,
             time_to_answer) as
SELECT row_number() OVER ()                                         AS id,
       c.livechat_operator_id                                       AS partner_id,
       c.livechat_channel_id,
       count(DISTINCT c.id)                                         AS nbr_channel,
       c.id                                                         AS channel_id,
       c.create_date                                                AS start_date,
       c.rating_last_value                                          AS rating,
       EXTRACT(epoch FROM max(m.create_date) - min(m.create_date))  AS duration,
       EXTRACT(epoch FROM min(mo.create_date) - min(m.create_date)) AS time_to_answer
FROM discuss_channel c
         JOIN mail_message m ON m.res_id = c.id AND m.model::text = 'discuss.channel'::text
         LEFT JOIN mail_message mo ON mo.res_id = c.id AND mo.model::text = 'discuss.channel'::text AND
                                      mo.author_id = c.livechat_operator_id
WHERE c.livechat_channel_id IS NOT NULL
GROUP BY c.id, c.livechat_operator_id;

alter table im_livechat_report_operator
    owner to crm;

