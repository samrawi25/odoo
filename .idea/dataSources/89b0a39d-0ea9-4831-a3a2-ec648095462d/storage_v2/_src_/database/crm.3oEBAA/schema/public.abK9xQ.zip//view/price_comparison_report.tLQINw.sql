create view price_comparison_report(id, date, product_id, competitor_id, source, price, company_id) as
SELECT id,
       date,
       product_id,
       competitor_id,
       source,
       price,
       company_id
FROM (SELECT ppl.id,
             ppl.changed_date::date    AS date,
             ppl.product_id,
             NULL::integer             AS competitor_id,
             'your'::text              AS source,
             ppl.new_price             AS price,
             COALESCE(u.company_id, 1) AS company_id
      FROM product_price_log ppl
               LEFT JOIN res_users u ON u.id = ppl.changed_by
      WHERE ppl.changed_date IS NOT NULL
        AND ppl.product_id IS NOT NULL
      UNION ALL
      SELECT mil.id + 1000000          AS id,
             mil.mi_date               AS date,
             mil.product_id,
             mil.competitor_id,
             'competitor'::text        AS source,
             mil.unit_price            AS price,
             COALESCE(u.company_id, 1) AS company_id
      FROM market_intelligence_market_intelligence_line mil
               LEFT JOIN res_users u ON u.id = mil.create_uid
      WHERE mil.mi_date IS NOT NULL
        AND mil.product_id IS NOT NULL) all_data
ORDER BY date, id;

alter table price_comparison_report
    owner to crm;

