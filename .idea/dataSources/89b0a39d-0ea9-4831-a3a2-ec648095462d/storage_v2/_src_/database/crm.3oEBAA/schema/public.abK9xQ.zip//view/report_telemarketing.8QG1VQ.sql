create view report_telemarketing
            (id, date, user_id, lead_id, call_type, call_status_display, direction, duration, total_calls, done_calls,
             brand_awareness_created, orders_generated, quality_rating, avg_service_rating, avg_product_rating,
             status_id, source_model, pending_calls)
as
SELECT c.id,
       c.date,
       c.user_id,
       c.lead_id,
       c.call_type,
       CASE c.state
           WHEN 'open'::text THEN 'Confirmed'::character varying
           WHEN 'cancel'::text THEN 'Cancelled'::character varying
           WHEN 'pending'::text THEN 'Pending'::character varying
           WHEN 'done'::text THEN 'Held'::character varying
           ELSE c.state
           END                                         AS call_status_display,
       c.direction,
       c.duration::numeric / 60.0                      AS duration,
       1                                               AS total_calls,
       CASE
           WHEN c.state::text = 'done'::text THEN 1
           ELSE 0
           END                                         AS done_calls,
       CASE
           WHEN c.brand_awareness_created THEN 1
           ELSE 0
           END                                         AS brand_awareness_created,
       (SELECT count(*) AS count
        FROM crm_telemarketing_call_sale_order_rel so_rel
        WHERE so_rel.crm_telemarketing_call_id = c.id) AS orders_generated,
       c.quality_rating,
       c.service_rating::double precision              AS avg_service_rating,
       c.product_rating::double precision              AS avg_product_rating,
       c.status_id,
       'telemarketing_dashboard'::text                 AS source_model,
       CASE
           WHEN c.state::text = 'pending'::text THEN 1
           ELSE 0
           END                                         AS pending_calls
FROM crm_telemarketing_call c
UNION ALL
SELECT p.id + 2000000                     AS id,
       p.date,
       p.user_id,
       p.opportunity_id                   AS lead_id,
       'sales'::character varying         AS call_type,
       CASE p.state
           WHEN 'open'::text THEN 'Confirmed'::character varying
           WHEN 'cancel'::text THEN 'Cancelled'::character varying
           WHEN 'pending'::text THEN 'Pending'::character varying
           WHEN 'done'::text THEN 'Held'::character varying
           ELSE p.state
           END                            AS call_status_display,
       CASE
           WHEN p.direction::text = 'in'::text THEN 'inbound'::text
           ELSE 'outbound'::text
           END                            AS direction,
       p.duration,
       1                                  AS total_calls,
       CASE
           WHEN p.state::text = 'done'::text THEN 1
           ELSE 0
           END                            AS done_calls,
       0                                  AS brand_awareness_created,
       0                                  AS orders_generated,
       NULL::character varying            AS quality_rating,
       p.service_rating::double precision AS avg_service_rating,
       p.product_rating::double precision AS avg_product_rating,
       NULL::integer                      AS status_id,
       'phonecall'::text                  AS source_model,
       CASE
           WHEN p.state::text = 'pending'::text THEN 1
           ELSE 0
           END                            AS pending_calls
FROM crm_phonecall p;

alter table report_telemarketing
    owner to crm;

