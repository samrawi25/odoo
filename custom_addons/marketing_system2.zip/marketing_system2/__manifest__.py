{
    'name': "Marketing & CRM System Extensions (Consolidated)",
    'version': "17.0.2.0.0",
    'summary': "Comprehensive suite for CRM, Telemarketing, KPI Management, Location Tracking, and Price Logging.",
    'description': """
        This module consolidates multiple Odoo extensions into a single system:
        - Advanced CRM Lead validation (TIN, Phone, Email).
        - Geo-location tracking for sales visits (Encounter Visits) with Leaflet Map View.
        - KPI Management Framework for user performance tracking.
        - Product Price Change Logging and comparison reporting (SQL View).
        - CRM View Cleanup (removes probability, priority, tags via post-init hook).
        - Telemarketing, Phone Call Summaries, and Competitor Management.
    """,
    'author': "Samrawi & Melese",
    'license': "LGPL-3",
    'category': "Sales/CRM",
    'depends': [
        'base',
        'web',
        'crm',
        'crm_phonecall',
        'mail',
        'product',
        'sales_team',
        'resource',
        'calendar',  # From crm_phonecall
        'sale_management',  # From crm_telemarketing
    ],
    'data': [
        'security/groups.xml',
        'security/telemarketer_groups.xml',
        'security/ir.model.access.csv',
        'security/ir_rules.xml',

        'data/lead_sequence.xml',
        'data/telemarketer_users.xml',
        'data/kpi_data.xml',
        'data/kpi_automated_actions.xml',

        'views/kpi_definition_views.xml',
        'views/kpi_target_views.xml',
        'views/kpi_target_line_views.xml',
        'views/kpi_history_views.xml',
        'views/telemarketing_confirmation_views.xml',
        'views/kpi_reporting_views.xml',

        'views/product_price_log_views.xml',
        'views/competitor_views.xml',

        'views/crm_lead_views.xml',
        'views/res_partner_views.xml',
        'views/encounter_visit_views.xml',

        'views/crm_telemarketing_status_views.xml',
        'views/telemarketing_report_views.xml',
        'views/telemarketing_dashboard_views.xml',
        'views/crm_phonecall_views.xml',

        'views/kpi_menus.xml',
    ],
    'assets': {
        "web.assets_backend": [
            "marketing_system2/static/src/js/*.js",
            "marketing_system2/static/src/xml/*.xml",
        ],
    },
    'installable': True,
    'application': True,
    'pre_init_hook': 'create_code_equal_to_id',
    'post_init_hook': 'post_init_wrapper',
}