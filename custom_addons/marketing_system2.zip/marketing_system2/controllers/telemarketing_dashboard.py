from odoo import http
from odoo.http import request
from collections import defaultdict
import logging

_logger = logging.getLogger(__name__)


class TelemarketingDashboardController(http.Controller):

    @http.route('/telemarketing/dashboard/data', type='json', auth='user', methods=['POST'])
    def get_dashboard_data(self, start_date=None, end_date=None):
        """
        Return KPIs, chart data, and pivot table data for the OWL dashboard.
        """
        # --- 1. Base Domain Setup ---
        date_domain = []
        if start_date:
            date_domain.append(('create_date', '>=', start_date))
        if end_date:
            date_domain.append(('create_date', '<=', end_date))

        # --- 2. Call KPIs (Top row cards) and Leads Data ---
        Report = request.env['report.telemarketing']

        kpi_calls = Report.read_group(
            domain=[],
            fields=['total_calls', 'done_calls', 'duration', 'pending_calls'],
            groupby=[],
        )
        kpi_row = kpi_calls[0] if kpi_calls else {}
        total_calls = kpi_row.get('total_calls', 0)
        done_calls = kpi_row.get('done_calls', 0)
        avg_duration = kpi_row.get('duration', 0.0)
        total_leads = request.env['crm.lead'].search_count(date_domain)
        converted_leads = request.env['crm.lead'].search_count(date_domain + [('type', '=', 'opportunity')])
        conversion_rate = round((converted_leads / total_leads) * 100, 2) if total_leads > 0 else 0.0
        total_competitors = request.env['competitor.competitor'].search_count([])

        # --- 3. Bar Chart Data: "Inbound vs Outbound by Day" ---
        chart_data_raw = Report.read_group(
            domain=[],
            fields=['total_calls'],
            groupby=['date:day', 'direction'],
            lazy=False
        )
        bar_chart_data = {'labels': [], 'datasets': {}}
        labels_set = set()
        for rec in chart_data_raw:
            day = rec['date:day']
            direction = rec['direction']
            count = rec['total_calls']
            labels_set.add(day)
            if direction not in bar_chart_data['datasets']:
                bar_chart_data['datasets'][direction] = {}
            bar_chart_data['datasets'][direction][day] = count
        bar_chart_data['labels'] = sorted(list(labels_set))

        # --- 4. Pivot Table Data: "Calls by User and Direction" ---
        pivot_data_raw = Report.read_group(
            domain=[],
            fields=['total_calls', 'done_calls', 'pending_calls'],
            groupby=['user_id', 'direction'],
            lazy=False
        )
        pivot_data = defaultdict(lambda: defaultdict(int))
        for rec in pivot_data_raw:
            user_name = rec['user_id'][1] if rec.get('user_id') else 'Unassigned'
            direction = rec['direction']
            pivot_data[user_name][f"{direction}_total"] = rec['total_calls']
            pivot_data[user_name][f"{direction}_done"] = rec['done_calls']
            pivot_data[user_name][f"{direction}_pending"] = rec['pending_calls']

        # --- 5. Salesperson KPI Summary (Leads/Conversion/KPIs) ---
        salesperson_data = defaultdict(lambda: {
            'salesperson': '',
            'total_leads': 0, 'converted_leads': 0, 'conversion_rate': 0.0,
            'leads_registered_target': 0, 'leads_registered_actual': 0, 'leads_registered_percent': 0.0,
            'data_quality_target': 0, 'data_quality_actual': 0, 'data_quality_percent': 0.0,
        })

        # Aggregate leads data by user
        leads_group = request.env['crm.lead'].read_group(
            domain=date_domain,
            fields=['user_id', 'type'],
            groupby=['user_id', 'type'],
            lazy=False
        )
        for rec in leads_group:
            user_name = rec['user_id'][1] if rec.get('user_id') else 'Unassigned'
            count = rec['user_id_count']
            salesperson_data[user_name]['salesperson'] = user_name
            salesperson_data[user_name]['total_leads'] += count
            if rec['type'] == 'opportunity':
                salesperson_data[user_name]['converted_leads'] += count

        for sp, data in salesperson_data.items():
            total = data['total_leads']
            converted = data['converted_leads']
            data['conversion_rate'] = round((converted / total) * 100, 2) if total else 0

        # Fetch KPI Target Lines (Filter by date)
        KpiLine = request.env['kpi.target.line']
        kpi_domain = []
        if start_date:
            kpi_domain.append(('date_end', '>=', start_date))
        if end_date:
            kpi_domain.append(('date_start', '<=', end_date))

        kpi_lines = KpiLine.search(kpi_domain)
        for line in kpi_lines:
            if line.user_id:
                sp = line.user_id.name
                salesperson_data[sp]['salesperson'] = sp

                if line.kpi_definition_id.kpi_type == 'leads_registered':
                    salesperson_data[sp]['leads_registered_target'] += line.target_value
                    salesperson_data[sp]['leads_registered_actual'] += line.actual_value
                    salesperson_data[sp]['leads_registered_percent'] = round(line.achievement_percentage, 2)

                elif line.kpi_definition_id.kpi_type == 'data_quality':
                    salesperson_data[sp]['data_quality_target'] += line.target_value
                    salesperson_data[sp]['data_quality_actual'] += line.actual_value
                    salesperson_data[sp]['data_quality_percent'] = round(line.achievement_percentage, 2)

        salesperson_result = list(salesperson_data.values())

        return {
            'kpis': {
                'total_leads': total_leads,
                'converted_leads': converted_leads,
                'conversion_rate': conversion_rate,
                'total_calls': total_calls,
                'avg_duration': round(avg_duration, 2),
                'total_competitors': total_competitors
            },
            'bar_chart': bar_chart_data,
            'pivot_table': {
                'headers': ['Inbound', 'Outbound'],
                'rows': pivot_data,
            },
            'salesperson_data': salesperson_result,
        }