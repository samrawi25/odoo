# marketing_system2/hooks.py
from .models.view_patch import remove_probability_from_views
from .models.models_phonecall import convert_names_to_many2one
import logging

_logger = logging.getLogger(__name__)


# --- Pre-Init Hook from crm_lead_code ---
def create_code_equal_to_id(env):
    """Adds the 'code' column to crm_lead before the module installs its views/constraints."""
    try:
        env.cr.execute("ALTER TABLE crm_lead ADD COLUMN code character varying;")
        env.cr.execute("UPDATE crm_lead SET code = id;")
        _logger.info("Pre-init hook: Added 'code' column to crm_lead.")
    except Exception as e:
        _logger.warning("Pre-init hook failed (code column): %s", str(e))
        pass


# --- Post-Init Hook Wrapper ---
def post_init_wrapper(env):
    """Runs all necessary post-installation hooks sequentially."""

    # 1. CRM Lead Code - Assigns new sequence codes to all existing leads
    def assign_old_sequences(env):
        lead_obj = env["crm.lead"].sudo()
        sequence_obj = env["ir.sequence"].sudo()
        leads = lead_obj.search([], order="id")
        _logger.info("Post-init: Assigning codes to %d existing leads.", len(leads))
        for lead in leads:
            try:
                env.cr.execute(
                    "UPDATE crm_lead SET code = %s WHERE id = %s;",
                    (
                        sequence_obj.next_by_code("crm.lead"),
                        lead.id,
                    ),
                )
            except Exception as e:
                _logger.warning("Failed to assign code to lead %s: %s", lead.id, str(e))
                env.cr.rollback()  # Rollback per-record update if it fails

    # 2. CRM Phonecall Summary - Converts old string summaries to Many2one
    _logger.info("Post-init: Running phone call summary conversion.")
    convert_names_to_many2one(env)

    # 3. CRM Probability Cleaner - Cleans up views
    _logger.info("Post-init: Running CRM view cleanup (probability/tags).")
    remove_probability_from_views(env)

    # Execute lead code assignment (must run last among data updates)
    assign_old_sequences(env)

    _logger.info("Post-init wrapper completed successfully.")