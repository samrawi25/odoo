# Base/Utility models first
from . import models_base

# CRITICAL: Remove models_phonecall_base import since we're using inheritance
# from . import models_phonecall_base     # REMOVED - causes model redefinition

# FUNCTIONAL AND EXTENSION MODELS
from . import models_competitor
from . import models_phonecall      # Extends crm.phonecall functionality
from . import models_telemarketing
from . import models_kpi
from . import models_product

# CONSOLIDATED EXTENSIONS (Contains all O2M and functional extensions)
from . import models_crm_functional

# REPORTS AND HOOKS
from . import report_telemarketing
from . import report_telemarketing_dashboard
from . import view_patch