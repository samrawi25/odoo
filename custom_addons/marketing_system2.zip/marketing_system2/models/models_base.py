from odoo import fields, models, api
import logging
_logger = logging.getLogger(__name__)


# 1. Leaflet Map View Type Declaration (from leaflet_map module)
class IrUiView(models.Model):
    _inherit = "ir.ui.view"

    type = fields.Selection(selection_add=[("lmap", "Leaflet Map")])


class WindowActionView(models.Model):
    _inherit = "ir.actions.act_window.view"

    view_mode = fields.Selection(selection_add=[("lmap", "Leaflet Map")], ondelete={"lmap": "cascade"})


# 2. ResConfigSettings (from kpi_management_framework module)
class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    telemarketing_prefix = fields.Char(
        string="Telemarketing Confirmation Prefix",
        default='CONF',
        help="Prefix used for Telemarketing Confirmation sequence numbers."
    )

    def set_values(self):
        super().set_values()
        self.env['ir.config_parameter'].sudo().set_param(
            'telemarketing.confirmation.prefix',
            self.telemarketing_prefix
        )

    @api.model
    def get_values(self):
        res = super().get_values()
        res.update({
            'telemarketing_prefix': self.env['ir.config_parameter'].sudo().get_param(
                'telemarketing.confirmation.prefix', default='CONF'
            ),
        })
        return res