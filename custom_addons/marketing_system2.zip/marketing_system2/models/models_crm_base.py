# This file is created to hold O2M fields that caused dependency errors.
# It loads just after crm.phonecall is defined.
from odoo import models, fields


# Redefine the base phonecall O2M on crm.lead for stability
class CrmLeadBasePhonecalls(models.Model):
    _inherit = "crm.lead"

    phonecall_ids = fields.One2many(
        comodel_name="crm.phonecall",
        inverse_name="opportunity_id",
        string="Phonecalls"
    )
    phonecall_count = fields.Integer(compute="_compute_phonecall_count")

    def _compute_phonecall_count(self):
        for lead in self:
            lead.phonecall_count = self.env["crm.phonecall"].search_count(
                [("opportunity_id", "=", lead.id)]
            )


# Redefine the base phonecall O2M on res.partner for stability
class ResPartnerBasePhonecalls(models.Model):
    _inherit = "res.partner"

    phonecall_ids = fields.One2many(
        comodel_name="crm.phonecall",
        inverse_name="partner_id",
        string="Phonecalls"
    )
    phonecall_count = fields.Integer(compute="_compute_phonecall_count")

    def _compute_phonecall_count(self):
        for partner in self:
            partner.phonecall_count = self.env["crm.phonecall"].search_count(
                [("partner_id", "=", partner.id)]
            )