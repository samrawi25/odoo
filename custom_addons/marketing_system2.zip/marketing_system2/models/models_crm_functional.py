from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import re
import logging

# Note: telemarketing.confirmation is defined in models_telemarketing.py, imported via __init__.py

_logger = logging.getLogger(__name__)


# 1. CRM Lead Extension (Functionally merged from all modules + phonecall O2M)
class CrmLead(models.Model):
    _inherit = 'crm.lead'

    # --- Phonecall O2M (CRITICAL) ---
    # These rely on partner_id/opportunity_id being defined in crm.phonecall (models_phonecall_base.py)
    phonecall_ids = fields.One2many(
        comodel_name="crm.phonecall",
        inverse_name="opportunity_id",
        string="Phonecalls"
    )
    phonecall_count = fields.Integer(compute="_compute_phonecall_count")

    # --- Fields from crm_lead_code ---
    code = fields.Char(
        string="Lead Number", required=True, default="New", readonly=True, copy=False
    )
    _sql_constraints = [
        ("crm_lead_unique_code", "UNIQUE (code)", _("The code must be unique!")),
    ]

    # --- Fields from crm_lead_geolocation ---
    latitude = fields.Float("Latitude", digits=(16, 6))
    longitude = fields.Float("Longitude", digits=(16, 6))
    company_ids = fields.Many2many(
        "res.company",
        string="Companies",
        required=True,
        help="Link market intelligence/geolocation to your companies."
    )

    # --- Fields from custom_crm ---
    company_type = fields.Selection([
        ('manufacturing', 'Manufacturing'),
        ('service', 'Service'),
        ('retail', 'Retail'),
        ('agriculture', 'Agriculture'),
        ('construction', 'Construction'),
        ('other', 'Other'),
    ], string="Industry / Company Type")
    tin_number = fields.Char(string="TIN Number")

    # --- Fields from encounter_visit ---
    encounter_visit_ids = fields.One2many("encounter.encounter_visit", "lead_id", string="Encounter Visits")
    encounter_visit_count = fields.Integer(compute="_compute_encounter_visit_count")

    # --- Fields from crm_telemarketing ---
    telemarketing_call_ids = fields.One2many(
        "crm.telemarketing.call",
        "lead_id",
        string="Telemarketing Calls"
    )
    data_quality_score = fields.Integer(
        string="Data Quality Score (%)",
        compute="_compute_data_quality_score",
        store=True,
        help="Score based on the latest data confirmation checks."
    )

    # --- Methods / Computes (Merged & Extended) ---

    def _compute_phonecall_count(self):
        for lead in self:
            lead.phonecall_count = self.env["crm.phonecall"].search_count(
                [("opportunity_id", "=", lead.id)]
            )

    def _compute_encounter_visit_count(self):
        for lead in self:
            lead.encounter_visit_count = len(lead.encounter_visit_ids)

    def action_view_encounter_visits(self):
        return {
            "name": "Encounter Visits",
            "type": "ir.actions.act_window",
            "res_model": "encounter.encounter_visit",
            "view_mode": "tree,form,lmap",
            "domain": [("lead_id", "=", self.id)],
            "context": {"default_lead_id": self.id, "default_partner_id": self.partner_id.id},
        }

    @api.depends(
        'phonecall_ids.name_confirmed', 'phonecall_ids.address_confirmed', 'phonecall_ids.phone_confirmed',
        'telemarketing_call_ids.name_confirmed', 'telemarketing_call_ids.address_confirmed',
        'telemarketing_call_ids.phone_confirmed'
    )
    def _compute_data_quality_score(self):
        for lead in self:
            latest_call = None

            TelemarketingCall = self.env['crm.telemarketing.call']
            StandardPhonecall = self.env['crm.phonecall']

            latest_custom_call = TelemarketingCall.search([
                ('lead_id', '=', lead.id), '|', '|', ('name_confirmed', '=', True), ('address_confirmed', '=', True),
                ('phone_confirmed', '=', True),
            ], order='date desc', limit=1)

            latest_standard_call = StandardPhonecall.search([
                ('opportunity_id', '=', lead.id), '|', '|', ('name_confirmed', '=', True),
                ('address_confirmed', '=', True), ('phone_confirmed', '=', True),
            ], order='date desc', limit=1)

            if latest_custom_call and latest_standard_call:
                latest_call = latest_custom_call if latest_custom_call.date > latest_standard_call.date else latest_standard_call
            elif latest_custom_call:
                latest_call = latest_custom_call
            elif latest_standard_call:
                latest_call = latest_standard_call

            if not latest_call:
                lead.data_quality_score = 0
                continue

            score = 0
            if latest_call.name_confirmed:
                score += 1
            if latest_call.address_confirmed:
                score += 1
            if latest_call.phone_confirmed:
                score += 1
            lead.data_quality_score = int((score / 3.0) * 100)

    def action_view_data_quality_calls(self):
        self.ensure_one()
        return {
            'name': 'Data Quality History',
            'type': 'ir.actions.act_window',
            'res_model': 'report.telemarketing',
            'view_mode': 'tree',
            'target': 'current',
            'domain': [
                ('lead_id', '=', self.id),
            ],
            'context': {
                'create': False,
            }
        }

    @api.constrains('phone', 'mobile')
    def _check_phone_number(self):
        phone_pattern = re.compile(r'^(?:\+251|251|0)?(9|7)\d{8}$')
        for lead in self:
            if lead.phone:
                cleaned_phone = lead.phone.replace(' ', '').replace('-', '')
                if not phone_pattern.match(cleaned_phone):
                    raise ValidationError(_(
                        "Invalid Phone Number format for '%s'. Please use a valid Ethiopian format (e.g., 09... or 07...)."
                    ) % lead.phone)

            if lead.mobile:
                cleaned_mobile = lead.mobile.replace(' ', '').replace('-', '')
                if not phone_pattern.match(cleaned_mobile):
                    raise ValidationError(_(
                        "Invalid Mobile Number format for '%s'. Please use a valid Ethiopian format (e.g., 09... or 07...)."
                    ) % lead.mobile)

    @api.constrains('email_from')
    def _check_email_format(self):
        for lead in self:
            if lead.email_from and '@' not in lead.email_from:
                raise ValidationError(_("'%s' is not a valid email address.") % lead.email_from)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("code", "New") == "New":
                # Note: The original sequence ref was 'marketing_system.sequence_lead'
                vals["code"] = self.env.ref(
                    "marketing_system.sequence_lead", raise_if_not_found=False
                ).next_by_id()

        records = super().create(vals_list)

        for rec in records:
            if rec.user_id:
                self.env['kpi.target'].sudo()._update_targets_for_user(
                    rec.user_id.id,
                    'crm.lead'
                )

        return records


# 2. Res Partner Extension (Functionally merged from encounter_visit + phonecall O2M)
class ResPartner(models.Model):
    _inherit = "res.partner"

    # --- Phonecall O2M (CRITICAL) ---
    phonecall_ids = fields.One2many(
        comodel_name="crm.phonecall",
        inverse_name="partner_id",
        string="Phonecalls"
    )
    phonecall_count = fields.Integer(compute="_compute_phonecall_count")

    # --- Fields for encounter_visit ---
    encounter_visit_ids = fields.One2many("encounter.encounter_visit", "partner_id", string="Encounter Visits")
    encounter_visit_count = fields.Integer(compute="_compute_encounter_visit_count")

    # --- Methods / Computes ---
    def _compute_phonecall_count(self):
        for partner in self:
            partner.phonecall_count = self.env["crm.phonecall"].search_count(
                [("partner_id", "=", partner.id)]
            )

    def _compute_encounter_visit_count(self):
        for partner in self:
            partner.encounter_visit_count = len(partner.encounter_visit_ids)

    def action_view_encounter_visits(self):
        return {
            "name": "Encounter Visits",
            "type": "ir.actions.act_window",
            "res_model": "encounter.encounter_visit",
            "view_mode": "tree,form,lmap",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id},
        }