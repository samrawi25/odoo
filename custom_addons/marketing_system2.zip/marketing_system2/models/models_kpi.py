from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
from datetime import timedelta
import logging

_logger = logging.getLogger(__name__)


# 1. KPI Definition (from kpi_management_framework)
class KpiDefinition(models.Model):
    _name = 'kpi.definition'
    _description = 'KPI Definition (KPI Library)'
    _order = 'name'

    name = fields.Char(string='KPI Name', required=True)
    description = fields.Text(string='Description')

    assigned_target_count = fields.Integer(
        string="Assigned Targets",
        compute="_compute_assigned_target_count",
        store=False
    )

    kpi_type = fields.Selection([
        ('leads_registered', 'Leads Registered'),
        ('data_quality', 'Data Quality'),
    ], string='KPI Type', required=True, default='leads_registered')

    confirmation_fields = fields.Selection([
        ('name_confirmed', 'Name Confirmation'),
        ('address_confirmed', 'Address Confirmation'),
        ('phone_confirmed', 'Phone Confirmation'),
        ('service_satisfaction_confirmed', 'Service Satisfaction'),
        ('product_information_confirmed', 'Product Information'),
        ('all_confirmations', 'All'),
    ], string='Confirmation Type', help="Which data quality metric to track")

    @api.depends()
    def _compute_assigned_target_count(self):
        targetLine = self.env['kpi.target.line']
        for rec in self:
            rec.assigned_target_count = targetLine.search_count([('kpi_definition_id', '=', rec.id)])

    def action_view_assigned_targets(self):
        self.ensure_one()
        return {
            'name': f"KPI Targets for {self.name}",
            'type': 'ir.actions.act_window',
            'res_model': 'kpi.target.line',
            'view_mode': 'tree,form',
            'domain': [('kpi_definition_id', '=', self.id)],
            'context': {'default_kpi_definition_id': self.id},
        }

    @api.constrains('kpi_type', 'confirmation_fields')
    def _check_confirmation_fields(self):
        for record in self:
            if record.kpi_type == 'data_quality' and not record.confirmation_fields:
                raise ValidationError("Confirmation Type is required for Data Quality KPIs.")


# 2. KPI Target (from kpi_management_framework)
class KpiTarget(models.Model):
    _name = 'kpi.target'
    _description = 'KPI Target Assignment'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', compute='_compute_name', store=True, readonly=True)
    user_id = fields.Many2one('res.users', string='Assigned To', required=True, tracking=True)
    date_start = fields.Date(string='Start Date', required=True)
    date_end = fields.Date(string='End Date', required=True)

    working_days = fields.Integer(
        string='Working Days (Calculated)',
        compute='_compute_working_days',
        store=True
    )

    target_line_ids = fields.One2many('kpi.target.line', 'target_id', string='KPI Lines')

    overall_achievement = fields.Float(
        string='Overall Achievement (%)',
        compute='_compute_overall_achievement',
        store=True
    )

    history_ids = fields.One2many('kpi.history', 'target_id', string='Activity History')
    activity_count = fields.Integer(string="Activity Count", compute='_compute_activity_count')
    last_computed_date = fields.Datetime(string='Last Computed On', readonly=True)

    data_quality_count = fields.Integer(
        string="Data Quality Activities",
        compute='_compute_data_quality_count',
        store=True
    )

    overall_achievement_leads = fields.Float(
        string='Overall Achievement (Leads)',
        compute='_compute_separate_achievements',
        store=True
    )

    overall_achievement_data_quality = fields.Float(
        string='Overall Achievement (Data Quality)',
        compute='_compute_separate_achievements',
        store=True
    )

    @api.depends('target_line_ids.achievement_percentage', 'target_line_ids.kpi_definition_id.kpi_type')
    def _compute_separate_achievements(self):
        for record in self:
            leads_lines = record.target_line_ids.filtered(
                lambda l: l.kpi_definition_id.kpi_type == 'leads_registered'
            )
            data_quality_lines = record.target_line_ids.filtered(
                lambda l: l.kpi_definition_id.kpi_type == 'data_quality'
            )

            if leads_lines:
                record.overall_achievement_leads = sum(
                    leads_lines.mapped('achievement_percentage')
                ) / len(leads_lines)
            else:
                record.overall_achievement_leads = 0.0

            if data_quality_lines:
                record.overall_achievement_data_quality = sum(
                    data_quality_lines.mapped('achievement_percentage')
                ) / len(data_quality_lines)
            else:
                record.overall_achievement_data_quality = 0.0

    @api.depends('user_id.name', 'date_start', 'date_end')
    def _compute_name(self):
        for record in self:
            if record.user_id and record.date_start and record.date_end:
                record.name = f"KPIs for {record.user_id.name} ({record.date_start.strftime('%b %Y')})"
            else:
                record.name = "New KPI Assignment"

    @api.depends('target_line_ids.achievement_percentage')
    def _compute_overall_achievement(self):
        for record in self:
            if record.target_line_ids:
                record.overall_achievement = sum(record.target_line_ids.mapped('achievement_percentage')) / len(
                    record.target_line_ids)
            else:
                record.overall_achievement = 0.0

    @api.depends('date_start', 'date_end', 'user_id.resource_calendar_id')
    def _compute_working_days(self):
        for rec in self:
            calendar = rec.user_id.resource_calendar_id

            if rec.date_start and rec.date_end and calendar:
                start_dt = fields.Datetime.to_datetime(rec.date_start)
                end_dt = fields.Datetime.to_datetime(rec.date_end) + timedelta(days=1)

                duration_data = calendar.get_work_duration_data(
                    start_dt,
                    end_dt,
                    compute_leaves=True
                )
                rec.working_days = round(duration_data.get('days', 0.0))
            else:
                rec.working_days = 0

    @api.depends('history_ids')
    def _compute_activity_count(self):
        for target in self:
            target.activity_count = len(target.history_ids)

    @api.depends('history_ids.data_quality_type')
    def _compute_data_quality_count(self):
        for target in self:
            target.data_quality_count = len(target.history_ids.filtered(
                lambda h: h.data_quality_type and h.data_quality_type != False
            ))

    def _get_target_line_id(self, target, kpi):
        line = target.target_line_ids.filtered(lambda l: l.kpi_definition_id == kpi)
        return line.id if line else False

    def action_view_activities(self):
        self.ensure_one()
        return {
            'name': _('Tracked Activities for %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'kpi.history',
            'view_mode': 'tree,form',
            'domain': [('target_id', '=', self.id)],
        }

    def action_view_data_quality(self):
        self.ensure_one()
        return {
            'name': _('Data Quality Activities'),
            'type': 'ir.actions.act_window',
            'res_model': 'kpi.history',
            'view_mode': 'tree,form',
            'domain': [('target_id', '=', self.id), ('data_quality_type', '!=', False)],
            'context': {'create': False},
        }

    def action_recalculate_values(self):
        self._recalculate_values()

    def _recalculate_values(self):
        KpiHistory = self.env['kpi.history']

        for target in self:
            _logger.info(f"Recalculating KPI Target: {target.name} for user {target.user_id.name}")

            # Clear all old history
            target.history_ids.unlink()
            history_vals_list = []

            for line in target.target_line_ids:
                kpi = line.kpi_definition_id
                _logger.info(f"Processing KPI line: {kpi.name} with type: {kpi.kpi_type}")

                calculated_value = 0.0

                if kpi.kpi_type == 'leads_registered':
                    calculated_value = self._calculate_leads_registered(target, kpi, history_vals_list)
                elif kpi.kpi_type == 'data_quality':
                    calculated_value = self._calculate_data_quality(target, kpi, history_vals_list)

                # Update the line with calculated value
                line.actual_value = calculated_value
                _logger.info(f"KPI '{kpi.name}' calculated value: {calculated_value}")

            # Create all history records in one batch
            if history_vals_list:
                KpiHistory.create(history_vals_list)
                _logger.info(f"Created {len(history_vals_list)} history records")

            # Update the master record's timestamp
            target.last_computed_date = fields.Datetime.now()
            _logger.info(f"Completed recalculation for KPI Target '{target.name}'.")

    def _calculate_leads_registered(self, target, kpi, history_vals_list):
        date_from = fields.Datetime.to_datetime(target.date_start)
        date_to = fields.Datetime.to_datetime(target.date_end) + timedelta(days=1) - timedelta(seconds=1)

        domain = [
            ('user_id', '=', target.user_id.id),
            ('create_date', '>=', date_from),
            ('create_date', '<=', date_to),
        ]

        try:
            leads = self.env['crm.lead'].search(domain)

            for lead in leads:
                history_vals_list.append({
                    'target_id': target.id,
                    'target_line_id': self._get_target_line_id(target, kpi),
                    'kpi_definition_id': kpi.id,
                    'source_document_model': 'crm.lead',
                    'source_document_id': lead.id,
                    'activity_date': lead.create_date,
                    'description': f"Lead Registered: {lead.name}"
                })

            return len(leads)

        except Exception as e:
            _logger.error(f"Error counting leads for KPI '{kpi.name}': {e}")
            return 0

    def _calculate_data_quality(self, target, kpi, history_vals_list):
        date_from = fields.Datetime.to_datetime(target.date_start)
        date_to = fields.Datetime.to_datetime(target.date_end) + timedelta(days=1) - timedelta(seconds=1)

        confirmation_domain = [
            ('telemarketer_id', '=', target.user_id.id),
            ('confirmation_date', '>=', date_from),
            ('confirmation_date', '<=', date_to),
        ]

        try:
            confirmations = self.env['telemarketing.confirmation'].search(confirmation_domain)

            total_score = 0
            confirmation_count = len(confirmations)

            for confirmation in confirmations:
                score = confirmation.overall_score
                total_score += score

                history_vals_list.append({
                    'target_id': target.id,
                    'target_line_id': self._get_target_line_id(target, kpi),
                    'kpi_definition_id': kpi.id,
                    'source_document_model': 'telemarketing.confirmation',
                    'source_document_id': confirmation.id,
                    'activity_date': confirmation.confirmation_date,
                    'description': f"Data Quality Check: {confirmation.name} - Score: {score:.1f}%",
                    'data_quality_score': score,
                    'data_quality_type': kpi.confirmation_fields,
                })

            if confirmation_count > 0:
                # The actual value of data quality is the average of individual data quality scores
                return total_score / confirmation_count
            return 0.0

        except Exception as e:
            _logger.error(f"Error calculating data quality for KPI '{kpi.name}': {e}")
            return 0.0

    @api.model
    def _cron_update_actual_values(self):
        _logger.info("Starting nightly KPI update cron job...")
        active_targets = self.search([('date_end', '>=', fields.Date.today())])
        active_targets._recalculate_values()
        _logger.info("Finished nightly KPI update cron job.")

    @api.model
    def _cron_notify_low_achievement(self):
        """Placeholder for low achievement notification logic (requested but not fully implemented in source)"""
        # Example logic:
        # low_targets = self.search([
        #     ('date_end', '>=', fields.Date.today()),
        #     ('overall_achievement', '<', 50.0) # Threshold
        # ])
        # for target in low_targets:
        #    target.message_post(body=f"WARNING: Overall KPI Achievement is {target.overall_achievement:.2f}%!")
        pass

    @api.model
    def _update_targets_for_user(self, user_id, model_name):
        if not user_id or not model_name:
            return

        _logger.info(f"Updating KPI targets for user {user_id} due to {model_name} change")

        active_targets = self.search([
            ('user_id', '=', user_id),
            ('date_end', '>=', fields.Date.today()),
            ('date_start', '<=', fields.Date.today()),
        ])

        if active_targets:
            _logger.info(f"Found {len(active_targets)} active targets to update")
            active_targets._recalculate_values()
        else:
            _logger.info("No active targets found to update")


# 3. KPI Target Line (from kpi_management_framework)
class KpiTargetLine(models.Model):
    _name = 'kpi.target.line'
    _description = 'KPI Target Line'
    _order = 'sequence, id'

    target_id = fields.Many2one('kpi.target', string='KPI Target', required=True, ondelete='cascade')
    sequence = fields.Integer(string='Sequence', default=10)

    kpi_definition_id = fields.Many2one(
        'kpi.definition',
        string='KPI Definition',
        required=True,
        ondelete='cascade',
    )

    user_id = fields.Many2one(related='target_id.user_id', store=True, string='Assigned User')

    target_value = fields.Float(string='Target Value', required=True, default=0.0)
    actual_value = fields.Float(string='Actual Value', readonly=True, default=0.0)

    achievement_percentage = fields.Float(
        string='Achievement (%)', digits=(5, 2),
        compute='_compute_achievement_percentage',
        store=True
    )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done')
    ], string='Status', default='draft')

    date_start = fields.Date(related='target_id.date_start', store=True)
    date_end = fields.Date(related='target_id.date_end', store=True)

    @api.depends('actual_value', 'target_value', 'kpi_definition_id.kpi_type')
    def _compute_achievement_percentage(self):
        for record in self:
            if record.target_value and record.target_value != 0:
                record.achievement_percentage = (record.actual_value / record.target_value) * 100
            else:
                record.achievement_percentage = 0.0

    @api.constrains('target_value')
    def _check_target_value(self):
        for rec in self:
            if rec.kpi_definition_id.kpi_type == 'data_quality':
                if not (0 <= rec.target_value <= 100):
                    raise ValidationError("Target value for Data Quality KPI must be between 0% and 100%.")
            elif rec.kpi_definition_id.kpi_type == 'leads_registered':
                if rec.target_value < 0:
                    raise ValidationError("Target value for Leads Registered KPI cannot be negative.")

    @api.onchange('kpi_definition_id')
    def _onchange_kpi_definition_id(self):
        for rec in self:
            if rec.kpi_definition_id.kpi_type == 'data_quality':
                if rec.target_value == 0.0:
                    rec.target_value = 75.0
            elif rec.kpi_definition_id.kpi_type == 'leads_registered':
                if rec.target_value == 0.0:
                    rec.target_value = 10.0

    @api.model
    def create(self, vals):
        if 'target_value' not in vals or vals.get('target_value') == 0.0:
            kpi_def_id = vals.get('kpi_definition_id')
            if kpi_def_id:
                kpi_def = self.env['kpi.definition'].browse(kpi_def_id)
                vals['target_value'] = 75.0 if kpi_def.kpi_type == 'data_quality' else 10.0
            else:
                vals['target_value'] = 0.0

        return super().create(vals)


# 4. KPI History (from kpi_management_framework)
class KpiHistory(models.Model):
    _name = 'kpi.history'
    _description = 'KPI Activity History Log'
    _order = 'activity_date desc, id desc'

    target_id = fields.Many2one('kpi.target', string='KPI Target', required=True, ondelete='cascade')
    target_line_id = fields.Many2one('kpi.target.line', string='KPI Target Line', readonly=True)
    kpi_definition_id = fields.Many2one('kpi.definition', string='KPI Definition', readonly=True)

    source_document_model = fields.Char(string='Source Model', readonly=True)
    source_document_id = fields.Integer(string='Source ID', readonly=True)
    source_document = fields.Reference(
        selection='_get_source_document_models',
        string='Source Document',
        compute='_compute_source_document',
        readonly=True
    )

    activity_date = fields.Datetime(string='Activity Date', readonly=True)
    description = fields.Text(string='Description', readonly=True)

    data_quality_score = fields.Float(string='Data Quality Score', digits=(5, 2), readonly=True)
    data_quality_type = fields.Selection([
        ('name_confirmed', 'Name Confirmed'),
        ('address_confirmed', 'Address Confirmed'),
        ('phone_confirmed', 'Phone Confirmed'),
        ('service_satisfaction_confirmed', 'Service Satisfaction'),
        ('product_information_confirmed', 'Product Information'),
        ('all_confirmations', 'All'),
    ], string='Data Quality Type', readonly=True)

    display_data_quality_type = fields.Char(
        string='Quality Type',
        compute='_compute_display_data_quality_type'
    )

    def _get_source_document_models(self):
        return [
            ('crm.lead', 'Lead/Opportunity'),
            ('telemarketing.confirmation', 'Telemarketing Confirmation'),
        ]

    def _compute_source_document(self):
        for rec in self:
            if rec.source_document_model and rec.source_document_id:
                rec.source_document = self.env[rec.source_document_model].browse(rec.source_document_id)
            else:
                rec.source_document = False

    @api.depends('data_quality_type')
    def _compute_display_data_quality_type(self):
        type_mapping = {
            'name_confirmed': 'Name',
            'address_confirmed': 'Address',
            'phone_confirmed': 'Phone',
            'service_satisfaction_confirmed': 'Service',
            'product_information_confirmed': 'Product',
            'all_confirmations': 'All',
        }
        for rec in self:
            if rec.data_quality_type:
                rec.display_data_quality_type = type_mapping.get(rec.data_quality_type, rec.data_quality_type)
            else:
                rec.display_data_quality_type = ''