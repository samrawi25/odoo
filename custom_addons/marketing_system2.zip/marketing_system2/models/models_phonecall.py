from odoo import _, api, fields, models
from functools import reduce
import time
import logging

_logger = logging.getLogger(__name__)


# ------------------------------------------------------------------------------
# 1. CRM Phonecall Summary Model (Base Model from crm_phonecall_summary_predefined)
# ------------------------------------------------------------------------------
class CRMPhonecallSummary(models.Model):
    _name = "crm.phonecall.summary"
    _description = "Crm Phonecall Summary"
    _sql_constraints = [
        ("name_unique", "UNIQUE (name)", "Name must be unique"),
    ]

    name = fields.Char(required=True)
    phonecall_ids = fields.One2many(
        comodel_name="crm.phonecall",
        inverse_name="summary_id",
        string="Phonecalls",
        help="Phonecalls with this summary.",
    )


# ------------------------------------------------------------------------------
# 2. CRM Phonecall Extension (Merges CrmPhonecallBase logic + all custom fields/methods)
# ------------------------------------------------------------------------------
class CrmPhonecall(models.Model):
    # This inherits from the base crm.phonecall model assumed to be defined just before this file
    _inherit = "crm.phonecall"

    # ====================================================================
    # FIELDS MERGED FROM ALL EXTENSION MODULES
    # ====================================================================

    # --- From crm_phonecall_summary_predefined (Overrides core 'name' field) ---
    name = fields.Char(
        related="summary_id.name",
        store=True,
        required=False,
        readonly=True,
    )
    summary_id = fields.Many2one(
        comodel_name="crm.phonecall.summary",
        string="Summary",
        required=True,
        ondelete="restrict",
    )

    # --- From crm_telemarketing (Data Quality + Ratings) ---
    service_rating = fields.Selection(
        [('1', 'Poor'), ('2', 'Fair'), ('3', 'Good'), ('4', 'Very Good'), ('5', 'Excellent')],
        string="Service Satisfaction"
    )
    product_rating = fields.Selection(
        [('1', 'Poor'), ('2', 'Fair'), ('3', 'Good'), ('4', 'Very Good'), ('5', 'Excellent')],
        string="Product Satisfaction"
    )
    name_confirmed = fields.Boolean(string="Name Confirmed")
    address_confirmed = fields.Boolean(string="Address Confirmed")
    phone_confirmed = fields.Boolean(string="Phone Confirmed")
    email_confirmed = fields.Boolean(string="Email Confirmed")
    notes = fields.Text(string="Additional Notes")
    service_satisfaction_confirmed = fields.Boolean(string="Service Satisfaction Confirmed")
    product_information_confirmed = fields.Boolean(string="Product Information Confirmed")

    overall_score = fields.Float(
        string="Overall Score",
        compute="_compute_overall_score",
        store=True,
    )
    confirmation_id = fields.Many2one(
        "telemarketing.confirmation",
        string="Telemarketing Confirmation",
        readonly=True,
    )

    # ====================================================================
    # METHODS MERGED/EXTENDED FROM ORIGINAL MODULES
    # ====================================================================

    @api.depends(
        "name_confirmed", "address_confirmed", "phone_confirmed",
        "service_satisfaction_confirmed", "product_information_confirmed"
    )
    def _compute_overall_score(self):
        """Calculate data quality score based on confirmed fields."""
        fields_to_check = [
            "name_confirmed", "address_confirmed", "phone_confirmed",
            "service_satisfaction_confirmed", "product_information_confirmed",
        ]
        for rec in self:
            confirmed_count = sum(1 for f in fields_to_check if getattr(rec, f))
            rec.overall_score = (confirmed_count / len(fields_to_check)) * 100 if fields_to_check else 0

    @api.model
    def create(self, vals):
        record = super().create(vals)

        # --- Auto-create telemarketing.confirmation (from crm_phonecall extension) ---
        if record.opportunity_id:
            confirmation_vals = {
                "lead_id": record.opportunity_id.id,
                # Use opportunity's user_id for KPI tracking
                "telemarketer_id": record.opportunity_id.user_id.id or self.env.user.id,
                "phonecall_id": record.id,
                "name_confirmed": record.name_confirmed,
                "address_confirmed": record.address_confirmed,
                "phone_confirmed": record.phone_confirmed,
                "service_satisfaction_confirmed": record.service_satisfaction_confirmed,
                "product_information_confirmed": record.product_information_confirmed,
            }

            # Use sudo() to ensure creation even with limited user permissions
            confirmation = self.env["telemarketing.confirmation"].sudo().create(confirmation_vals)
            record.confirmation_id = confirmation.id

        return record

    def write(self, values):
        """Override to add case management: open/close dates."""
        if values.get("state"):
            if values.get("state") == "done":
                values["date_closed"] = fields.Datetime.now()
                self.compute_duration()
            elif values.get("state") == "open":
                values["date_open"] = fields.Datetime.now()
                values["duration"] = 0.0
        return super().write(values)

    def compute_duration(self):
        """Calculate duration based on phonecall date."""
        phonecall_dates = self.filtered("date")
        for phonecall in phonecall_dates:
            if phonecall.duration <= 0 and phonecall.date:
                duration = fields.Datetime.now() - phonecall.date
                values = {"duration": duration.seconds / 60.0}
                phonecall.write(values)
            else:
                phonecall.duration = 0.0
        return True

    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        """Contact number details should be change based on partner."""
        if self.partner_id:
            self.partner_phone = self.partner_id.phone
            self.partner_mobile = self.partner_id.mobile

    @api.onchange("opportunity_id")
    def _onchange_opportunity_id(self):
        """Based on opportunity, change contact, tags, partner, team."""
        if self.opportunity_id:
            self.team_id = self.opportunity_id.team_id.id
            self.partner_phone = self.opportunity_id.phone
            self.partner_mobile = self.opportunity_id.mobile
            self.partner_id = self.opportunity_id.partner_id.id
            self.tag_ids = self.opportunity_id.tag_ids.ids

    # From crm_phonecall_summary_predefined
    def get_values_schedule_another_phonecall(self, vals):
        # Includes the 'summary_id' key from crm_phonecall_summary_predefined logic
        res = {
            "name": vals.get("name"),
            "user_id": vals.get("user_id") or self.user_id.id,
            "description": self.description,
            "date": vals.get("schedule_time") or self.date,
            "team_id": vals.get("team_id") or self.team_id.id,
            "partner_id": self.partner_id.id,
            "partner_phone": self.partner_phone,
            "partner_mobile": self.partner_mobile,
            "priority": self.priority,
            "opportunity_id": self.opportunity_id.id,
            "campaign_id": self.campaign_id.id,
            "source_id": self.source_id.id,
            "medium_id": self.medium_id.id,
            "summary_id": vals.get("summary_id"),  # CRITICAL: Add summary_id
        }
        if vals.get("tag_ids"):
            res.update({"tag_ids": [(6, 0, vals.get("tag_ids"))]})
        return res


# ------------------------------------------------------------------------------
# 3. CRM Phonecall to Phonecall Wizard (from crm_phonecall_summary_predefined)
# ------------------------------------------------------------------------------
class CrmPhonecall2phonecall(models.TransientModel):
    _inherit = "crm.phonecall2phonecall"

    # Overrides core 'name' field
    name = fields.Char(
        related="summary_id.name",
        store=True,
        required=False,
        readonly=True,
    )
    summary_id = fields.Many2one(
        comodel_name="crm.phonecall.summary",
        string="Summary",
        required=True,
        ondelete="restrict",
    )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        model = self.env.context.get("active_model")
        if model == "crm.phonecall":
            phonecall = self.env[model].browse(self.env.context.get("active_id"))
            res["summary_id"] = phonecall.summary_id.id
        if 'action' in fields_list and 'action' not in res:
            res["action"] = "schedule"
        if 'date' in fields_list and 'date' not in res:
            res["date"] = fields.Datetime.now()
        return res

    def get_vals_action_schedule(self):
        res = super().get_vals_action_schedule()
        # CRITICAL: Pass the summary ID to the next call
        res.update({"summary_id": self.summary_id.id})
        return res


# ------------------------------------------------------------------------------
# 4. Post-init hook helper (used in hooks.py)
# ------------------------------------------------------------------------------
def convert_names_to_many2one(env):  # pragma: no cover
    """Converts old string summaries on phonecalls to the new Many2one field."""
    summary_model = env["crm.phonecall.summary"].sudo()
    phone_call_model = env["crm.phonecall"].sudo()

    for call in phone_call_model.search([("summary_id", "=", False)]):
        if call.name:
            try:
                with env.cr.savepoint():
                    call.summary_id = summary_model.create({"name": call.name})
            except Exception:
                call.summary_id = summary_model.search([("name", "=", call.name)], limit=1)