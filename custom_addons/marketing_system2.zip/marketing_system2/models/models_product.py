from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


# 1. Product Price Log (from product_price_log module)
class ProductPriceLog(models.Model):
    _name = "product.price.log"
    _description = "Product Price Log"

    product_id = fields.Many2one('product.product', string="Product", required=True)
    old_price = fields.Float(string="Old Price")
    new_price = fields.Float(string="New Price")
    changed_date = fields.Datetime(string="Changed On", default=fields.Datetime.now)
    changed_by = fields.Many2one('res.users', string="Changed By", default=lambda self: self.env.user)


# 2. Product Product Extension (from product_price_log module)
class ProductProduct(models.Model):
    _inherit = "product.product"

    def write(self, vals):
        res = super().write(vals)
        if 'lst_price' in vals:
            for product in self:
                old_price = product.lst_price
                new_price = vals['lst_price']
                if old_price != new_price:
                    _logger.info("Product %s price changed from %s to %s", product.name, old_price, new_price)
                    self.env['product.price.log'].create({
                        'product_id': product.id,
                        'old_price': old_price,
                        'new_price': new_price,
                    })
        return res


# 3. Product Template Extension (from product_price_log module)
class ProductTemplate(models.Model):
    _inherit = "product.template"

    def write(self, vals):
        log_vals_list = []
        if 'list_price' in vals:
            for template in self:
                old_price = template.list_price
                new_price = vals['list_price']
                if old_price != new_price:
                    for product in template.product_variant_ids:
                        log_vals_list.append({
                            'product_id': product.id,
                            'old_price': old_price,
                            'new_price': new_price,
                        })

        res = super().write(vals)

        # Create logs after the super() call to ensure data is saved
        if log_vals_list:
            self.env['product.price.log'].create(log_vals_list)

        return res


# 4. Price Comparison Report (SQL View from product_price_log module)
class PriceComparisonReport(models.Model):
    _name = "price.comparison.report"
    _description = "Price vs Competitor Report"
    _auto = False  # SQL view, not a real table
    _order = "date asc"
    # Multi-company pattern from the architecture framework
    company_id = fields.Many2one('res.company', string='Company', index=True)
    date = fields.Date("Date")
    product_id = fields.Many2one("product.product", string="Product")
    competitor_id = fields.Many2one("competitor.competitor", string="Competitor")
    source = fields.Selection([
        ('your', 'AMG Price'),
        ('competitor', 'Competitor Price')
    ], string="Source")
    price = fields.Float("Price")

    def init(self):
        """SQL View: merge product price log + competitor price"""
        # FIX 1: Drop view before recreating to prevent column definition conflicts
        self.env.cr.execute("DROP VIEW IF EXISTS price_comparison_report")

        # The Market Intelligence module (dependency) is not provided,
        # so we assume its table structure for the query to work.
        # Ensure the query uses the correct table/model names for dependencies.
        self.env.cr.execute("""
                            CREATE OR REPLACE VIEW price_comparison_report AS
                            (
                            SELECT id,
                                   date,
                                   product_id,
                                   company_id,
                                   competitor_id,
                                   source,
                                   price
                            FROM (
                                     -- Your product price log
                                     SELECT ppl.id                 as id,
                                            ppl.changed_date::date as date,
                                            ppl.product_id,
                                            pt.company_id,
                                            NULL::int              as competitor_id,
                                            'your'::varchar        as source,
                                            ppl.new_price          as price
                                     FROM product_price_log ppl
                                              JOIN product_product pp ON pp.id = ppl.product_id
                                              JOIN product_template pt ON pt.id = pp.product_tmpl_id


                                     UNION ALL

                                     -- Competitor market intelligence (ASSUMED STRUCTURE)
                                     SELECT mil.id + 1000000      as id,
                                            mil.mi_date           as date,
                                            mil.product_id,
                                            pt.company_id,
                                            mil.competitor_id,
                                            'competitor'::varchar as source,
                                            mil.unit_price        as price
                                     FROM market_intelligence_market_intelligence_line mil
                                              JOIN product_product pp ON pp.id = mil.product_id
                                              JOIN product_template pt ON pt.id = pp.product_tmpl_id) AS all_data
                            ORDER BY date ASC, id ASC
                                )
                            """)