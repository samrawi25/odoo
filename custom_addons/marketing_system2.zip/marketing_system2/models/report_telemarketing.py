from odoo import fields, models, tools


class ReportTelemarketing(models.Model):
    _name = "report.telemarketing"
    _description = "Telemarketing Report (Unified Calls)"
    _auto = False
    _rec_name = "date"

    date = fields.Datetime("Date", readonly=True)
    user_id = fields.Many2one("res.users", "Responsible", readonly=True)
    lead_id = fields.Many2one("crm.lead", "Lead/Opportunity", readonly=True)

    # Use a display field for status as the raw status fields differ between models
    call_status_display = fields.Char("Status", readonly=True)

    direction = fields.Selection(
        [("inbound", "Inbound"), ("outbound", "Outbound")],
        string="Direction", readonly=True
    )

    duration = fields.Float("Duration (min)", readonly=True, group_operator='avg')
    total_calls = fields.Integer("Total Calls", readonly=True)
    done_calls = fields.Integer("Completed Calls", readonly=True)
    brand_awareness_created = fields.Integer(string="# Brand Awareness", readonly=True)
    orders_generated = fields.Integer(string="# Orders Generated", readonly=True)
    quality_rating = fields.Selection([('1', '⭐'), ('2', '⭐⭐'), ('3', '⭐⭐⭐'), ('4', '⭐⭐⭐⭐'), ('5', '⭐⭐⭐⭐⭐')],
                                      string="Quality Rating", readonly=True)
    avg_service_rating = fields.Float(string="Avg Service Rating", readonly=True, group_operator='avg')
    avg_product_rating = fields.Float(string="Avg Product Rating", readonly=True, group_operator='avg')
    status_id = fields.Many2one("crm.telemarketing.status", "Detailed Status", readonly=True)

    source_model = fields.Selection([("telemarketing", "Telemarketing"), ("phonecall", "Phone Call")], string="Source",
                                    readonly=True)
    pending_calls = fields.Integer("Pending Calls", readonly=True)
    call_type = fields.Selection([("sales", "Sales Call"), ("survey", "Satisfaction Survey")], string="Call Type",
                                 readonly=True)

    # Merged logic for different phonecall models
    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
                         CREATE or REPLACE VIEW report_telemarketing AS
                         (
                         -- 1. Custom Telemarketing Calls (crm.telemarketing.call)
                         SELECT c.id,
                                c.date,
                                c.user_id,
                                c.lead_id,
                                c.call_type,
                                CASE c.state
                                    WHEN 'open' THEN 'Confirmed'
                                    WHEN 'cancel' THEN 'Cancelled'
                                    WHEN 'pending' THEN 'Pending'
                                    WHEN 'done' THEN 'Held'
                                    ELSE c.state
                                    END                                               AS call_status_display,
                                c.direction,
                                (c.duration / 60.0)                                   AS duration,
                                1                                                     AS total_calls,
                                CASE WHEN c.state = 'done' THEN 1 ELSE 0 END          AS done_calls,
                                CASE WHEN c.brand_awareness_created THEN 1 ELSE 0 END AS brand_awareness_created,
                                (SELECT COUNT(*)
                                 FROM crm_telemarketing_call_sale_order_rel so_rel
                                 WHERE so_rel.crm_telemarketing_call_id = c.id)       AS orders_generated,
                                c.quality_rating,
                                CAST(c.service_rating AS FLOAT)                       AS avg_service_rating,
                                CAST(c.product_rating AS FLOAT)                       AS avg_product_rating,
                                c.status_id,
                                'telemarketing'                                       AS source_model,
                                CASE WHEN c.state = 'pending' THEN 1 ELSE 0 END       AS pending_calls
                         FROM crm_telemarketing_call c

                         UNION ALL

                         -- 2. Standard Odoo Phonecalls (crm.phonecall)
                         SELECT p.id + 2000000                                                  AS id,        -- Ensure unique ID
                                p.date,
                                p.user_id,
                                p.opportunity_id                                                AS lead_id,
                                'sales'                                                         AS call_type, -- Default to sales for standard calls
                                CASE p.state
                                    WHEN 'open' THEN 'Confirmed'
                                    WHEN 'cancel' THEN 'Cancelled'
                                    WHEN 'pending' THEN 'Pending'
                                    WHEN 'done' THEN 'Held'
                                    ELSE p.state
                                    END                                                         AS call_status_display,
                                CASE WHEN p.direction = 'in' THEN 'inbound' ELSE 'outbound' END AS direction,
                                p.duration,
                                1                                                               AS total_calls,
                                CASE WHEN p.state = 'done' THEN 1 ELSE 0 END                    AS done_calls,
                                0                                                               AS brand_awareness_created,
                                0                                                               AS orders_generated,
                                NULL                                                            AS quality_rating,
                                CAST(p.service_rating AS FLOAT)                                 AS avg_service_rating,
                                CAST(p.product_rating AS FLOAT)                                 AS avg_product_rating,
                                NULL                                                            AS status_id,
                                'phonecall'                                                     AS source_model,
                                CASE WHEN p.state = 'pending' THEN 1 ELSE 0 END                 AS pending_calls
                         FROM crm_phonecall p
                             )
                         """)