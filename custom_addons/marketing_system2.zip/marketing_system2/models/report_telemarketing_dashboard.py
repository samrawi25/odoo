from odoo import api, fields, models
import logging

_logger = logging.getLogger(__name__)


class ReportTelemarketingDashboard(models.TransientModel):
    _name = "report.telemarketing_dashboard.dashboard"
    _description = "Telemarketing Dashboard (Transient)"

    # These fields are computed only to allow Odoo's internal mechanisms
    # to recognize the model as having data, though the actual computation
    # logic will be performed by the controller/API call.
    total_calls = fields.Integer("Total Calls", compute="_compute_dashboard_data", readonly=True)
    done_calls = fields.Integer("Completed Calls", compute="_compute_dashboard_data", readonly=True)
    pending_calls = fields.Integer("Pending Calls", compute="_compute_dashboard_data", readonly=True)
    avg_duration = fields.Float("Average Duration (min)", compute="_compute_dashboard_data", readonly=True)
    completion_rate = fields.Float("Completion Rate (%)", compute="_compute_dashboard_data", readonly=True)

    # Use a dummy compute method as the real data fetching is in the controller's JSON endpoint
    @api.depends()
    def _compute_dashboard_data(self):
        # This method is primarily to satisfy ORM requirements for fields with compute=True.
        # The actual data is retrieved via the /telemarketing/dashboard/data API route.
        for record in self:
            record.total_calls = 0
            record.done_calls = 0
            record.pending_calls = 0
            record.avg_duration = 0.0
            record.completion_rate = 0.0

    @api.model
    def get_dashboard_data(self, start_date=None, end_date=None):
        """
        Helper to fetch simple, top-level KPIs from the consolidated report view.
        (Called by the HTTP controller)
        """
        Report = self.env['report.telemarketing'].search([])

        # Use read_group for efficient aggregation
        read_group_data = self.env['report.telemarketing'].read_group(
            domain=[],
            fields=['total_calls:sum', 'done_calls:sum', 'duration:avg', 'pending_calls:sum'],
            groupby=[],
        )

        row = read_group_data[0] if read_group_data else {}
        total = row.get('total_calls', 0)
        done = row.get('done_calls', 0)
        pending = row.get('pending_calls', 0)
        avg_duration = row.get('duration', 0.0)
        completion_rate = (done / total * 100.0) if total > 0 else 0.0

        return {
            "total_calls": total,
            "done_calls": done,
            "pending_calls": pending,
            "avg_duration": round(avg_duration, 2),
            "completion_rate": round(completion_rate, 2),
        }