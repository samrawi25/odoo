from odoo import SUPERUSER_ID
import logging
from lxml import etree
import re

_logger = logging.getLogger(__name__)


def remove_probability_from_views(env):
    """Post-init hook for Odoo 17: remove probability, tag_ids, and priority fields from views."""

    # 1. Search for views that contain ANY of the target elements
    views = env['ir.ui.view'].sudo().search([
        '|', '|',
        ('arch_db', 'ilike', 'probability'),
        ('arch_db', 'ilike', 'tag_ids'),
        ('arch_db', 'ilike', 'priority')
    ])
    _logger.info("marketing_system2: scanning %d view(s) for target fields", len(views))

    for view in views:
        arch = view.arch_db or ''
        changed = False

        try:
            # 2. Use LXML (The preferred, safer method)
            doc = etree.fromstring(arch.encode('utf-8'))

            # Combined XPath for all fields and related labels/divs
            elements_to_remove = doc.xpath(
                "//field[@name='probability'] | //label[@for='probability'] | //div[contains(@class, 'probability')] | " +
                "//field[@name='priority'] | //label[@for='priority'] | //div[contains(@class, 'priority')] | " +
                "//field[@name='tag_ids'] | //label[@for='tag_ids']"
            )

            for element in elements_to_remove:
                parent = element.getparent()
                # Use remove() instead of trying to replace the whole node,
                # as the parent might be the surrounding <group> or <header>
                if parent is not None:
                    parent.remove(element)
                    changed = True

            # Additional cleanup for statusbar buttons/widgets related to these fields
            # This is complex, but essential for a clean result
            # E.g., removing 'widget="priority"' from a surrounding tag is too aggressive with regex

            if changed:
                new_arch = etree.tostring(doc, encoding='utf-8').decode('utf-8')
                # 3. Write the cleaned view
                view.write({'arch_db': new_arch})
                _logger.info("marketing_system2: cleaned fields from view %s", view.xml_id or view.id)

        except Exception as e:
            # 4. Fallback: Aggressive Regex (Only if LXML fails)
            _logger.warning("marketing_system2: XML parsing failed for view %s, skipping cleanup: %s",
                            view.xml_id or view.id, str(e))
            # The regex fallback is highly error-prone and is best avoided,
            # so we log and skip instead of risking database corruption.