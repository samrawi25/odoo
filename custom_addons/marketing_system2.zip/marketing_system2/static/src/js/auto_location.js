/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { FormController } from "@web/views/form/form_controller";
import { onMounted } from "@odoo/owl";

patch(FormController.prototype, {
    setup() {
        super.setup(...arguments);

        // Only run for the encounter.encounter_visit model
        onMounted(() => {
            if (this.model.root.resModel === "encounter.encounter_visit") {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            if (
                                this.model.root.fields.latitude &&
                                this.model.root.fields.longitude
                            ) {
                                this.model.root.update({
                                    latitude: +position.coords.latitude.toFixed(6),
                                    longitude: +position.coords.longitude.toFixed(6),
                                });
                            }
                        },
                        (err) => {
                            console.warn("Geolocation error:", err);
                        }
                    );
                }
            }
        });
    }
});