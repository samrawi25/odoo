# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import res_partner
from . import res_partner_industry
from . import res_config_settings
