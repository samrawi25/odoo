To manage industries, you need to:

- Go to *Contacts \> Configuration \> Industries*.

By default only companies have industries. To activate industries in
individuals also, you need to activate the following setting:

- Go to *Settings \> General Settings \> Partner Industries \> Industry
  in contacts \> Use industry for individuals*
