This module adds secondary industries for partners.
