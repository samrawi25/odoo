To use this module, you need to:

- Go to any partner's form.
